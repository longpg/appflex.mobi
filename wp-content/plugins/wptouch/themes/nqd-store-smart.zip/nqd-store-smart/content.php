<?php
/**
 * @package NQD-Store-Smart
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class('store'); ?>>
	<a href="<?php the_permalink();?>" title="<?php the_title();?>" class="info">
		<span class="ribbon ribbon_<?php if(strtotime($post->post_date_gmt)==strtotime($post->post_modified_gmt)) echo 'new'; else echo 'update';?>"></span>
		<span class="ribbon ribbon_free"></span>
		<span class="shadown"><img alt="<?php the_title();?>" src="<?php bloginfo('home'); ?>/media/resizer/64x64/r/<?php echo remove_http(catch_that_image($post));?>"></span>
		<span class="comment"><?php the_title();?></span>
		<span class="post_date"><?php echo time_stamp(get_post_time('U', true)); ?></span>
		<?php $rating = wp_gdsr_rating_article ($post->ID);	?>
		<span class="rating-static rating-<?php echo round($rating->rating)*10;?>"></span>
		<span class="post_comment"><?php comments_number('0','1','%');?></span>
		<span class="post_view"><?php if(function_exists('the_views')) { the_views(); } ?></span>
	</a>
	<a class="btn app-bottom btn-down-ind" href="<?php bloginfo('home'); ?>/detail/<?php echo $post->ID?>" title="Tải về <?php the_title();?>"><i class="icon-download-alt"></i>Tải về</a>
</article><!-- #post-## -->
