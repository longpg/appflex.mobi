<?php
/**
 * The Header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="content">
 *
 * @package NQD-Store-Smart
 */
  global $NHP_Options;
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php wp_title( '|', true, 'right' ); ?></title>
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<?php wp_head(); ?>
<?php $NHP_Options->show('header_script');?>
</head>

<body <?php body_class(); ?>>
<div id="page" class="hfeed site">
	<?php do_action( 'before' ); ?>
	<header id="masthead" class="site-header" role="banner">
		<div class="nav">
		<?php 
			if(is_single()):
		?>
			<h2><a href="<?php bloginfo('home');?>" title="<?php bloginfo('description');?>" class="logo"><?php bloginfo('name');?></a></h2>
		<?php else:?>
			<h1><a href="<?php bloginfo('home');?>" title="<?php bloginfo('description');?>" class="logo"><?php bloginfo('name');?></a></h1>
		<?php endif;?>
			<i class="icon-menu"></i>
		</div>
	</header><!-- #masthead -->
	<div id="top-menu" class="menu">
			<ul>
				<li class="active">
					<a href="<?php bloginfo('home');?>/moi-nhat" title="Tải game mới nhất">Mới nhất</a>
				</li>
				<li class="active">
					<a href="<?php bloginfo('home');?>/tai-nhieu-nhat" title="Tải game mới nhất">Tải nhiều nhất</a>
				</li>
				<li class="active">
					<a href="<?php bloginfo('home');?>/xem-nhieu-nhat" title="Tải game mới nhất">Xem nhiều nhất</a>
				</li>
				<li class="active">
					<a href="<?php bloginfo('home');?>/binh-chon-nhieu-nhat" title="Tải game mới nhất">Bình chọn nhiều nhất</a>
				</li>
			</ul>
	</div>
	<div id="content" class="site-content">
