<?php
/**
 * The Sidebar containing the main widget areas.
 *
 * @package NQD-Store-Smart
 */
?>
	<div style="" id="rbMenu">
			<div class="element">
				<h3><i class="icon-search icon-white"></i> Tìm kiếm</h3>
				<form method="get" action="">
					<input type="text" placeholder="Nhập từ khóa..." value="" name="s">&nbsp;<input type="submit" class="btn" value="Go!">
				</form>
			</div>
			<div class="element">
				<h3><i class="icon-folder-open icon-white"></i> Danh mục</h3>
				<ul>
					<?php wp_list_categories('orderby=name&hierarchical=0&&title_li='); ?> 
				</ul>
			</div>
			<div class="element">
				<h3><i class="icon-archive icon-white"></i> Lưu trữ</h3>
				<ul>
				<?php wp_get_archives( array( 'type' => 'monthly', 'limit' => 12 ) ); ?>
				</ul>
			</div>
			<div class="element">
				<h3>&copy; <?php echo date("Y")?> <?php bloginfo('title');?></h3>
			</div>
		</div>
