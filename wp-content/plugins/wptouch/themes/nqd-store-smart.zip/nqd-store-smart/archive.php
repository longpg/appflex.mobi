<?php
/**
 * The template for displaying Archive pages.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package NQD-Store-Smart
 */

get_header(); ?>

	<section id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
		<?php NQD_Breadcrumbs();?>
		<?php if ( have_posts() ) : ?>
			<?php
					// Show an optional term description.
					$term_description = term_description();
					if ( ! empty( $term_description ) ) :
			?>
			<header class="page-header">
				<?php
				printf( '<div class="taxonomy-description">%s</div>', $term_description );
				?>
			</header><!-- .page-header -->
			<?php
				endif;
				?>
			<?php /* Start the Loop */ ?>
			<?php while ( have_posts() ) : the_post(); ?>
				<?php
					get_template_part( 'content', get_post_format() );
				?>

			<?php endwhile; ?>
			<div class='page-pagination'>
			<?php pagination( ); ?>
			</div>
		<?php else : ?>

			<?php get_template_part( 'no-results', 'archive' ); ?>

		<?php endif; ?>
			<div>
			<h2>Xem nhiều nhất chuyên mục</h2>
			<?php 
				$category = get_the_category($post->ID);
				$category = $category[0]->cat_ID;
				$args1 = array(
						'posts_per_page' => 5,
						'paged' => 1,
						'category__in' => array($category), 
						'post_status'=>'publish',
						'orderby' =>'meta_value_num',
						'meta_key' => 'views',
						'order' => 'DESC'
				);
				$my_query = new WP_Query($args1);
			?>
			<?php while ( $my_query->have_posts() ) : $my_query->the_post(); ?>
					<?php
						get_template_part( 'content', get_post_format() );
					?>
			<?php endwhile;
				wp_reset_query();
			?>
			</div>
		</main><!-- #main -->
	</section><!-- #primary -->
	<?php get_sidebar();?>
<?php get_footer(); ?>
